#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"
#include "inc/ssd1306.h"

// Biblioteca gerada pelo arquivo .pio durante compilação.
#include "ws2818b.pio.h"

// Definição do número de LEDs e pino.
#define LED_COUNT 25
#define LED_PIN 7
#define RED_LED_PIN 11
#define GREEN_LED_PIN 12
#define BLUE_LED_PIN 13
#define BUTTON_A 5
#define BUTTON_B 6
#define I2C_SDA 14
#define I2C_SCL 15



// Definição de pixel GRB
struct pixel_t {
  uint8_t G, R, B; // Três valores de 8-bits compõem um pixel.
};
typedef struct pixel_t pixel_t;
typedef pixel_t npLED_t; // Mudança de nome de "struct pixel_t" para "npLED_t" por clareza.

// Declaração do buffer de pixels que formam a matriz.
npLED_t leds[LED_COUNT];

// Variáveis para uso da máquina PIO.
PIO np_pio;
uint sm;

/**
 * Inicializa a máquina PIO para controle da matriz de LEDs.
 */
void npInit(uint pin) {

  // Cria programa PIO.
  uint offset = pio_add_program(pio0, &ws2818b_program);
  np_pio = pio0;

  // Toma posse de uma máquina PIO.
  sm = pio_claim_unused_sm(np_pio, false);
  if (sm < 0) {
    np_pio = pio1;
    sm = pio_claim_unused_sm(np_pio, true); // Se nenhuma máquina estiver livre, panic!
  }

  // Inicia programa na máquina PIO obtida.
  ws2818b_program_init(np_pio, sm, offset, pin, 800000.f);

  // Limpa buffer de pixels.
  for (uint i = 0; i < LED_COUNT; ++i) {
    leds[i].R = 0;
    leds[i].G = 0;
    leds[i].B = 0;
  }
}

/**
 * Atribui uma cor RGB a um LED.
 */
void npSetLED(const uint index, const uint8_t r, const uint8_t g, const uint8_t b) {
  leds[index].R = r;
  leds[index].G = g;
  leds[index].B = b;
}

/**
 * Limpa o buffer de pixels.
 */
void npClear() {
  for (uint i = 0; i < LED_COUNT; ++i)
    npSetLED(i, 0, 0, 0);
}

/**
 * Escreve os dados do buffer nos LEDs.
 */
void npWrite() {
  // Escreve cada dado de 8-bits dos pixels em sequência no buffer da máquina PIO.
  for (uint i = 0; i < LED_COUNT; ++i) {
    pio_sm_put_blocking(np_pio, sm, leds[i].G);
    pio_sm_put_blocking(np_pio, sm, leds[i].R);
    pio_sm_put_blocking(np_pio, sm, leds[i].B);
  }
  sleep_us(100); // Espera 100us, sinal de RESET do datasheet.
}

//mapeamento "zig-zag" na matriz
int getIndex(int x, int y){
	if(y%2 == 0){
		return 24-(y * 5 + x);
	}else{
		return 24-(y * 5 + (4-x));
	}
}

//numeros que aparecem na matriz de led
void numero_zero(){
  int numero[5][5][3]={
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,255,255}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,255,255}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,255,255}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha,coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}
void numero_um(){
  int numero[5][5][3]={
      {{255,255,255}, {255,255,255}, {0,255,0}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha, coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}
void numero_dois(){
  int numero[5][5][3]={
      {{255,255,255}, {0,0,255}, {0,0,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {0,0,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {255,255,255}, {255,255,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {0,0,255}, {0,0,255}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha, coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}
void numero_tres(){
  int numero[5][5][3]={
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha, coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}
void numero_quatro(){
  int numero[5][5][3]={
      {{255,255,255}, {0,255,0}, {255,255,255}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {0,255,0}, {255,255,255}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {0,255,0}, {0,255,0}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha, coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}
void numero_cinco(){
  int numero[5][5][3]={
      {{255,255,255}, {0,0,255}, {0,0,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {255,255,255}, {255,255,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {0,0,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {0,0,255}, {0,0,255}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha, coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}
void numero_seis(){
  int numero[5][5][3]={
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,255,255}, {255,255,255}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,255,255}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha, coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}
void numero_sete(){
  int numero[5][5][3]={
      {{255,255,255}, {0,255,0}, {0,255,0}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {0,255,0}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha, coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}
void numero_oito(){
  int numero[5][5][3]={
      {{255,255,255}, {0,0,255}, {0,0,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {255,255,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {0,0,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {255,255,255}, {0,0,255}, {255,255,255}},
      {{255,255,255}, {0,0,255}, {0,0,255}, {0,0,255}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha, coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}
void numero_nove(){
  int numero[5][5][3]={
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,255,255}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,0,0}, {255,0,0}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {255,0,0}, {255,255,255}},
      {{255,255,255}, {255,255,255}, {255,255,255}, {255,0,0}, {255,255,255}}};
  for(int linha = 0; linha<5; linha++){
          for(int coluna = 0; coluna <5; coluna++){
              int posicao = getIndex(linha, coluna);
              npSetLED(posicao, numero[coluna][linha][0],numero[coluna][linha][1],numero[coluna][linha][2]);
          }
      }
  npWrite();
}

void exibir_num(char numero){
  switch(numero){
  case '0':
    numero_zero();
    break;
  case '1':
    numero_um();
    break;
  case '2':
    numero_dois();
    break;
  case '3':
    numero_tres();
    break;
  case '4':
    numero_quatro();
    break;
  case '5':
    numero_cinco();
    break;
  case '6':
    numero_seis();
    break;
  case '7':
    numero_sete();
    break;
  case '8':
    numero_oito();
    break;
  case '9':
    numero_nove();
    break;
  default:
    npClear();
    break;
  }
  npWrite();
}

// Variáveis para armazenar o estado dos LEDs
bool led_verde_estado = false;
bool led_azul_estado = false;

// Função para configurar os botões e LEDs
void configurar_hardware() {
    // Configuração dos botões
    gpio_init(BUTTON_A);
    gpio_set_dir(BUTTON_A, GPIO_IN);
    gpio_pull_up(BUTTON_A);

    gpio_init(BUTTON_B);
    gpio_set_dir(BUTTON_B, GPIO_IN);
    gpio_pull_up(BUTTON_B);

    // Configuração dos LEDs
    gpio_init(GREEN_LED_PIN);
    gpio_set_dir(GREEN_LED_PIN, GPIO_OUT);
    gpio_put(GREEN_LED_PIN, led_verde_estado);

    gpio_init(BLUE_LED_PIN);
    gpio_set_dir(BLUE_LED_PIN, GPIO_OUT);
    gpio_put(BLUE_LED_PIN, led_azul_estado);
}

ssd1306_t ssd;

// Função para atualizar o display OLED
void atualizar_display(const char *mensagem) {
    ssd1306_fill(&ssd, false);
    ssd1306_draw_string(&ssd,mensagem,5,5);
    ssd1306_send_data(&ssd);
}

//vai poder exibir no monitor
void monitor(char caracter){
  if (stdio_usb_connected()) {
    if (scanf("%c", &caracter)) {
      printf("Caractere recebido: %c\n", caracter);
      exibir_num(caracter); // Exibe o número na matriz de LEDs
    }
  }
}

// Função para tratar o botão A (alternar LED verde)
void tratar_botao_a() {
    // Alterna o estado do LED Verde
    led_verde_estado = !led_verde_estado;
    gpio_put(GREEN_LED_PIN, led_verde_estado);

    // Atualiza o display e Serial Monitor
    const char *msg = led_verde_estado ? "LED Verde ON" : "LED Verde OFF";
    printf("Botão A pressionado: %s\n", msg);
    atualizar_display(msg);
}

// Função para tratar o botão B (alternar LED azul)
void tratar_botao_b() {
    // Alterna o estado do LED Azul
    led_azul_estado = !led_azul_estado;
    gpio_put(BLUE_LED_PIN, led_azul_estado);

    // Atualiza o display e Serial Monitor
    const char *msg = led_azul_estado ? "LED Azul ON" : "LED Azul OFF";
    printf("Botão B pressionado: %s\n", msg);
    atualizar_display(msg);
}

int main() {

  // Inicializa entradas e saídas.
  stdio_init_all();

  // Inicializa matriz de LEDs NeoPixel.
  npInit(LED_PIN);
  npClear();

  npWrite(); 
  configurar_hardware();
  
  char caracter;
  // Não faz mais nada. Loop infinito.
  while (true) {
    if (!gpio_get(BUTTON_A)) { // Botão A pressionado
      tratar_botao_a();
      sleep_ms(300); // Debounce simples
    }
    if (!gpio_get(BUTTON_B)) { // Botão B pressionado
      tratar_botao_b();
      sleep_ms(300); // Debounce simples
    }
    monitor(caracter);
    sleep_ms(200); // Delay para não sobrecarregar o loop
  }
}